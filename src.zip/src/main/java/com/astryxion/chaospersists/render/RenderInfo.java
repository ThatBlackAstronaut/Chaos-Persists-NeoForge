/*
 * Decompiled with CFR 0_125.
 * 
 * Could not load the following classes:
 *  com.astryxion.chaospersists.RenderInfo
 */
package com.astryxion.chaospersists.render;

public class RenderInfo {
    public int ri1;
    public int ri2;
    public int ri3;
    public int ri4;
    public float rf1;
    public float rf2;
    public float rf3;
    public float rf4;
}

