/*
 * Decompiled with CFR 0_125.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 *  com.astryxion.chaospersists.BlockCrystalTorch
 *  com.astryxion.chaospersists.ChaosPersists
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockTorch
 *  net.minecraft.client.renderer.texture.IIconRegister
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.util.IIcon
 *  net.minecraft.world.IBlockAccess
 *  net.minecraft.world.World
 *  net.minecraftforge.common.util.EnumFacing
 */
package com.astryxion.chaospersists.block;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import com.astryxion.chaospersists.core.ChaosPersists;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockTorch;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.util.EnumFacing;

public class BlockCrystalTorch
extends BlockTorch {
    public BlockCrystalTorch() { this(0); }
    public BlockCrystalTorch(int par1) {
        this.setCreativeTab(CreativeTabs.DECORATIONS);
    }

    @SideOnly(value=Side.CLIENT)
    public void randomDisplayTick(World par1World, int par2, int par3, int par4, Random par5Random) {
        if (par1World.rand.nextInt(4) != 1) {
            return;
        }
        int var6 = this.getMetaFromState(par1World.getBlockState(new net.minecraft.util.math.BlockPos(par2, par3, par4)));
        double var7 = (float)par2 + 0.5f;
        double var9 = (float)par3 + 0.7f;
        double var11 = (float)par4 + 0.5f;
        double var13 = 0.213;
        double var15 = 0.271;
        if (var6 == 1) {
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.FIREWORKS_SPARK, var7 - var15, var9 + var13, var11, (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 8.0f), (double)(par1World.rand.nextFloat() / 8.0f), (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 8.0f));
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.FLAME, var7 - var15, var9 + var13, var11, (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 60.0f), (double)(par1World.rand.nextFloat() / 10.0f), (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 60.0f));
        } else if (var6 == 2) {
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.FIREWORKS_SPARK, var7 + var15, var9 + var13, var11, (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 8.0f), (double)(par1World.rand.nextFloat() / 8.0f), (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 8.0f));
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.FLAME, var7 + var15, var9 + var13, var11, (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 60.0f), (double)(par1World.rand.nextFloat() / 10.0f), (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 60.0f));
        } else if (var6 == 3) {
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.FIREWORKS_SPARK, var7, var9 + var13, var11 - var15, (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 8.0f), (double)(par1World.rand.nextFloat() / 8.0f), (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 8.0f));
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.FLAME, var7, var9 + var13, var11 - var15, (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 60.0f), (double)(par1World.rand.nextFloat() / 10.0f), (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 60.0f));
        } else if (var6 == 4) {
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.FIREWORKS_SPARK, var7, var9 + var13, var11 + var15, (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 8.0f), (double)(par1World.rand.nextFloat() / 8.0f), (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 8.0f));
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.FLAME, var7, var9 + var13, var11 + var15, (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 60.0f), (double)(par1World.rand.nextFloat() / 10.0f), (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 60.0f));
        } else {
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.FIREWORKS_SPARK, var7, var9, var11, (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 8.0f), (double)(par1World.rand.nextFloat() / 8.0f), (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 8.0f));
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.FLAME, var7, var9, var11, (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 60.0f), (double)(par1World.rand.nextFloat() / 10.0f), (double)((par1World.rand.nextFloat() - par1World.rand.nextFloat()) / 60.0f));
        }
    }

    private boolean isCrystalBlock(World par1World, int par2, int par3, int par4) {
        Block l = par1World.getBlockState(new net.minecraft.util.math.BlockPos(par2, par3, par4)).getBlock();
        if (l == ChaosPersists.CrystalStone) {
            return true;
        }
        if (l == ChaosPersists.CrystalGrass) {
            return true;
        }
        if (l == ChaosPersists.MyCrystalTreeLog) {
            return true;
        }
        if (l == ChaosPersists.CrystalPlanksBlock) {
            return true;
        }
        return false;
    }

    private boolean isItSolidOnSide(World par1World, int par2, int par3, int par4, EnumFacing dir, boolean tf) {
        if (this.isCrystalBlock(par1World, par2, par3, par4)) {
            return true;
        }
        return par1World.isSideSolid(new net.minecraft.util.math.BlockPos(par2, par3, par4), dir, tf);
    }

    private boolean canPlaceTorchOn(World par1World, int par2, int par3, int par4) {
        Block l = par1World.getBlockState(new net.minecraft.util.math.BlockPos(par2, par3, par4)).getBlock();
        if (this.isCrystalBlock(par1World, par2, par3, par4)) {
            return true;
        }
        net.minecraft.util.math.BlockPos pos = new net.minecraft.util.math.BlockPos(par2, par3, par4);
        net.minecraft.block.state.IBlockState state = par1World.getBlockState(pos);
        if (par1World.isSideSolid(pos, net.minecraft.util.EnumFacing.UP)) {
            return true;
        }
        return l != null && l.canPlaceTorchOnTop(state, (net.minecraft.world.IBlockAccess)par1World, pos);
    }

    public boolean canPlaceBlockAt(World par1World, int par2, int par3, int par4) {
        return this.isItSolidOnSide(par1World, par2 - 1, par3, par4, EnumFacing.EAST, true) || this.isItSolidOnSide(par1World, par2 + 1, par3, par4, EnumFacing.WEST, true) || this.isItSolidOnSide(par1World, par2, par3, par4 - 1, EnumFacing.SOUTH, true) || this.isItSolidOnSide(par1World, par2, par3, par4 + 1, EnumFacing.NORTH, true) || this.canPlaceTorchOn(par1World, par2, par3 - 1, par4);
    }

    public int onBlockPlaced(World par1World, int par2, int par3, int par4, int par5, float par6, float par7, float par8, int par9) {
        int j1 = par9;
        if (par5 == 1 && this.canPlaceTorchOn(par1World, par2, par3 - 1, par4)) {
            j1 = 5;
        }
        if (par5 == 2 && (par1World.isSideSolid(new net.minecraft.util.math.BlockPos(par2, par3, par4 + 1), EnumFacing.NORTH, true) || this.isCrystalBlock(par1World, par2, par3, par4 + 1))) {
            j1 = 4;
        }
        if (par5 == 3 && (par1World.isSideSolid(new net.minecraft.util.math.BlockPos(par2, par3, par4 - 1), EnumFacing.SOUTH, true) || this.isCrystalBlock(par1World, par2, par3, par4 - 1))) {
            j1 = 3;
        }
        if (par5 == 4 && (par1World.isSideSolid(new net.minecraft.util.math.BlockPos(par2 + 1, par3, par4), EnumFacing.WEST, true) || this.isCrystalBlock(par1World, par2 + 1, par3, par4))) {
            j1 = 2;
        }
        if (par5 == 5 && (par1World.isSideSolid(new net.minecraft.util.math.BlockPos(par2 - 1, par3, par4), EnumFacing.EAST, true) || this.isCrystalBlock(par1World, par2 - 1, par3, par4))) {
            j1 = 1;
        }
        return j1;
    }}

