/*
 * Decompiled with CFR 0_125.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 *  com.astryxion.chaospersists.BlockExtremeTorch
 *  com.astryxion.chaospersists.ChaosPersists
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockTorch
 *  net.minecraft.block.material.Material
 *  net.minecraft.client.renderer.texture.IIconRegister
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityList
 *  net.minecraft.entity.EntityLiving
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.IIcon
 *  net.minecraft.world.World
 */
package com.astryxion.chaospersists.block;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import com.astryxion.chaospersists.core.ChaosPersists;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockTorch;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

/*
 * Exception performing whole class analysis ignored.
 */
public class BlockExtremeTorch
extends BlockTorch {
    public BlockExtremeTorch() { this(0); }
    public BlockExtremeTorch(int par1) {
        this.setCreativeTab(CreativeTabs.REDSTONE);
    }

    @SideOnly(value=Side.CLIENT)
    public void randomDisplayTick(World par1World, int par2, int par3, int par4, Random par5Random) {
        net.minecraft.util.math.BlockPos pos = new net.minecraft.util.math.BlockPos(par2, par3, par4);
        int var6 = this.getMetaFromState(par1World.getBlockState(pos));
        double var7 = (float)par2 + 0.5f;
        double var9 = (float)par3 + 0.7f;
        double var11 = (float)par4 + 0.5f;
        double var13 = 0.213;
        double var15 = 0.271;
        if (var6 == 1) {
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.SMOKE_NORMAL, var7 - var15, var9 + var13, var11, 0.0, 0.0, 0.0);
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.FLAME, var7 - var15, var9 + var13, var11, 0.0, 0.0, 0.0);
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.REDSTONE, var7 - var15, var9 + var13, var11, 0.0, 0.0, 0.0);
        } else if (var6 == 2) {
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.SMOKE_NORMAL, var7 + var15, var9 + var13, var11, 0.0, 0.0, 0.0);
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.FLAME, var7 + var15, var9 + var13, var11, 0.0, 0.0, 0.0);
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.REDSTONE, var7 + var15, var9 + var13, var11, 0.0, 0.0, 0.0);
        } else if (var6 == 3) {
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.SMOKE_NORMAL, var7, var9 + var13, var11 - var15, 0.0, 0.0, 0.0);
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.FLAME, var7, var9 + var13, var11 - var15, 0.0, 0.0, 0.0);
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.REDSTONE, var7, var9 + var13, var11 - var15, 0.0, 0.0, 0.0);
        } else if (var6 == 4) {
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.SMOKE_NORMAL, var7, var9 + var13, var11 + var15, 0.0, 0.0, 0.0);
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.FLAME, var7, var9 + var13, var11 + var15, 0.0, 0.0, 0.0);
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.REDSTONE, var7, var9 + var13, var11 + var15, 0.0, 0.0, 0.0);
        } else {
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.SMOKE_NORMAL, var7, var9, var11, 0.0, 0.0, 0.0);
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.FLAME, var7, var9, var11, 0.0, 0.0, 0.0);
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.REDSTONE, var7, var9, var11, 0.0, 0.0, 0.0);
        }
    }

    public boolean canPlaceBlockAt(World par1World, net.minecraft.util.math.BlockPos pos) {
        return super.canPlaceBlockAt(par1World, pos);
    }

    public void onBlockPlacedBy(World world, net.minecraft.util.math.BlockPos pos, net.minecraft.block.state.IBlockState state, EntityLivingBase par5EntityLiving, ItemStack par6ItemStack) {
        int par2 = pos.getX();
        int par3 = pos.getY();
        int par4 = pos.getZ();
        int x = par2;
        int y = par3;
        int z = par4;
        boolean found = false;
        if (world.getBlockState(new net.minecraft.util.math.BlockPos(x, y - 1, z)).getBlock() == ChaosPersists.MyEyeOfEnderBlock) {
            block0 : for (int tries = 0; tries < 100 && !found; ++tries) {
                x = world.rand.nextInt(2) == 0 ? par2 + 4 + world.rand.nextInt(3) - world.rand.nextInt(3) : par2 - 4 + world.rand.nextInt(3) - world.rand.nextInt(3);
                z = world.rand.nextInt(2) == 0 ? par4 + 4 + world.rand.nextInt(3) - world.rand.nextInt(3) : par4 - 4 + world.rand.nextInt(3) - world.rand.nextInt(3);
                for (y = par3 - 2; y <= par3 + 2; ++y) {
                    net.minecraft.util.math.BlockPos below = new net.minecraft.util.math.BlockPos(x, y - 1, z);
                    net.minecraft.block.state.IBlockState belowState = world.getBlockState(below);
                    if (!belowState.getBlock().getMaterial(belowState).isSolid() || world.getBlockState(new net.minecraft.util.math.BlockPos(x, y, z)).getBlock() != Blocks.AIR || world.getBlockState(new net.minecraft.util.math.BlockPos(x, y + 1, z)).getBlock() != Blocks.AIR) continue;
                    found = true;
                    continue block0;
                }
            }
            if (found) {
                if (!world.isRemote) {
                    Entity ent = null;
                    ent = BlockExtremeTorch.spawnCreature((World)world, (String)"Cephadrome", (double)((double)x + 0.5), (double)((double)y + 0.01), (double)((double)z + 0.5));
                } else {
                    for (int var3 = 0; var3 < 16; ++var3) {
                        world.spawnParticle(net.minecraft.util.EnumParticleTypes.SMOKE_NORMAL, (double)((float)par2 + world.rand.nextFloat() - world.rand.nextFloat()), (double)((float)par3 + world.rand.nextFloat()), (double)((float)par4 + world.rand.nextFloat() - world.rand.nextFloat()), 0.0, 0.0, 0.0);
                        world.spawnParticle(net.minecraft.util.EnumParticleTypes.EXPLOSION_NORMAL, (double)((float)par2 + world.rand.nextFloat() - world.rand.nextFloat()), (double)((float)par3 + world.rand.nextFloat()), (double)((float)par4 + world.rand.nextFloat() - world.rand.nextFloat()), 0.0, 0.0, 0.0);
                        world.spawnParticle(net.minecraft.util.EnumParticleTypes.REDSTONE, (double)((float)par2 + world.rand.nextFloat() - world.rand.nextFloat()), (double)((float)par3 + world.rand.nextFloat()), (double)((float)par4 + world.rand.nextFloat() - world.rand.nextFloat()), 0.0, 0.0, 0.0);
                    }
                }
                if (par5EntityLiving != null) {
                    world.playSound(par5EntityLiving.posX, par5EntityLiving.posY, par5EntityLiving.posZ, net.minecraft.util.SoundEvent.REGISTRY.getObject(new net.minecraft.util.ResourceLocation("entity.generic.explode")), net.minecraft.util.SoundCategory.BLOCKS, 1.0f, world.rand.nextFloat() * 0.2f + 0.9f, false);
                } else {
                    world.playSound((double)par2, (double)par3, (double)par4, net.minecraft.util.SoundEvent.REGISTRY.getObject(new net.minecraft.util.ResourceLocation("entity.generic.explode")), net.minecraft.util.SoundCategory.BLOCKS, 1.0f, world.rand.nextFloat() * 0.2f + 0.9f, false);
                }
                world.setBlockState(pos, Blocks.AIR.getDefaultState());
            }
        }
        super.onBlockPlacedBy(world, pos, state, par5EntityLiving, par6ItemStack);
    }

    public static Entity spawnCreature(World par0World, String par1, double par2, double par4, double par6) {
        Entity var8 = null;
        var8 = EntityList.createEntityByIDFromName(new net.minecraft.util.ResourceLocation(par1.contains(":") ? par1.split(":")[0] : "chaospersists", par1.contains(":") ? par1.split(":")[1] : par1), par0World);
        if (var8 != null) {
            var8.setLocationAndAngles(par2, par4, par6, par0World.rand.nextFloat() * 360.0f, 0.0f);
            par0World.spawnEntity(var8);
            ((EntityLiving)var8).playLivingSound();
        }
        return var8;
    }}

