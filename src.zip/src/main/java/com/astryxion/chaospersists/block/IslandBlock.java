/*
 * Decompiled with CFR 0_125.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 *  com.astryxion.chaospersists.IslandBlock
 *  com.astryxion.chaospersists.ChaosPersists
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockReed
 *  net.minecraft.block.material.Material
 *  net.minecraft.client.renderer.texture.IIconRegister
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityList
 *  net.minecraft.entity.EntityLiving
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.util.IIcon
 *  net.minecraft.world.World
 */
package com.astryxion.chaospersists.block;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import com.astryxion.chaospersists.core.ChaosPersists;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockReed;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.world.World;

/*
 * Exception performing whole class analysis ignored.
 */
public class IslandBlock
extends BlockReed {
    public IslandBlock() { this(0); }
    protected IslandBlock(int par1) {
        super();
        this.setTickRandomly(true);
        this.setCreativeTab(CreativeTabs.DECORATIONS);
    }

    @Override
    public net.minecraft.util.math.AxisAlignedBB getBoundingBox(net.minecraft.block.state.IBlockState state, net.minecraft.world.IBlockAccess source, net.minecraft.util.math.BlockPos pos) {
        float var3 = 0.375f;
        return new net.minecraft.util.math.AxisAlignedBB(0.5 - var3, 0.0, 0.5 - var3, 0.5 + var3, 1.0, 0.5 + var3);
    }

    public boolean canPlaceBlockAt(World par1World, int par2, int par3, int par4) {
        net.minecraft.block.state.IBlockState state = par1World.getBlockState(new net.minecraft.util.math.BlockPos(par2, par3 - 1, par4));
        if (state.getBlock().getMaterial(state).isSolid()) {
            return true;
        }
        return false;
    }

    public void randomDisplayTick(World par1World, int par2, int par3, int par4, Random par5Random) {
        if (par1World.rand.nextInt(20) != 1) {
            return;
        }
        for (int j1 = 0; j1 < 20; ++j1) {
            par1World.spawnParticle(net.minecraft.util.EnumParticleTypes.VILLAGER_HAPPY, (double)((float)par2 + par1World.rand.nextFloat()), (double)par3 + (double)par1World.rand.nextFloat(), (double)((float)par4 + par1World.rand.nextFloat()), 0.0, 0.0, 0.0);
        }
    }

    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random) {
        boolean isok = true;
        if (par1World.isRemote) {
            return;
        }
        int n = 1 + par1World.rand.nextInt(3);
        int m = 64;
        if (ChaosPersists.IslandSizeFactor == 2) {
            m = 55;
        }
        if (ChaosPersists.IslandSizeFactor == 1) {
            m = 45;
        }
        for (int i = 0; i < n; ++i) {
            int height = 12 + par1World.rand.nextInt(m);
            isok = true;
            block1 : for (int k = -10; k <= 10; ++k) {
                for (int j = -10; j <= 10; ++j) {
                    Block bid = par1World.getBlockState(new net.minecraft.util.math.BlockPos(par2 + j, par3 + height, par4 + k)).getBlock();
                    if (bid == Blocks.AIR) continue;
                    isok = false;
                    continue block1;
                }
            }
            if (!isok) continue;
            if (par1World.rand.nextInt(25) == 1) {
                IslandBlock.spawnCreature((World)par1World, (String)"Island", (double)par2, (double)(par3 + height), (double)par4);
                continue;
            }
            IslandBlock.spawnCreature((World)par1World, (String)"IslandToo", (double)par2, (double)(par3 + height), (double)par4);
        }
        par1World.setBlockState(new net.minecraft.util.math.BlockPos(par2, par3, par4), Blocks.AIR.getDefaultState(), 2);
        par1World.setBlockState(new net.minecraft.util.math.BlockPos(par2, par3 + 1, par4), Blocks.AIR.getDefaultState(), 2);
    }

    public Item getItemDropped(int par1, Random par2Random, int par3) {
        return Item.getItemFromBlock((Block)ChaosPersists.MyIslandBlock);
    }

    public int quantityDropped(Random par1Random) {
        return 1;
    }

    public static Entity spawnCreature(World par0World, String par1, double par2, double par4, double par6) {
        Entity var8 = null;
        var8 = EntityList.createEntityByIDFromName(new net.minecraft.util.ResourceLocation(par1), par0World);
        if (var8 != null) {
            var8.setLocationAndAngles(par2, par4, par6, par0World.rand.nextFloat() * 360.0f, 0.0f);
            par0World.spawnEntity(var8);
            ((EntityLiving)var8).playLivingSound();
        }
        return var8;
    }}

