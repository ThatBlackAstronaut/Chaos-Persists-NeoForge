/*
 * Decompiled with CFR 0_125.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 *  com.astryxion.chaospersists.BlockScaryLeaves
 *  com.astryxion.chaospersists.ChaosPersists
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockLeaves
 *  net.minecraft.client.renderer.texture.IIconRegister
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.IIcon
 *  net.minecraft.world.IBlockAccess
 *  net.minecraft.world.World
 */
package com.astryxion.chaospersists.block;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import com.astryxion.chaospersists.core.ChaosPersists;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockScaryLeaves
extends BlockLeaves {
    public BlockScaryLeaves() { this(0); }
    protected BlockScaryLeaves(int par1) {
        this.setSoundType(net.minecraft.block.SoundType.PLANT);
        this.setTickRandomly(true);
        this.setDefaultState(this.blockState.getBaseState().withProperty(DECAYABLE, true).withProperty(CHECK_DECAY, true));
    }

    @Override
    protected BlockStateContainer createBlockState() {
        return new BlockStateContainer(this, DECAYABLE, CHECK_DECAY);
    }

    @Override
    public IBlockState getStateFromMeta(int meta) {
        return this.getDefaultState().withProperty(DECAYABLE, (meta & 8) != 0).withProperty(CHECK_DECAY, (meta & 4) != 0);
    }

    @Override
    public int getMetaFromState(IBlockState state) {
        int i = 0;
        if (state.getValue(CHECK_DECAY)) i |= 4;
        if (state.getValue(DECAYABLE)) i |= 8;
        return i;
    }

    @Override
    public net.minecraft.block.BlockPlanks.EnumType getWoodType(int meta) {
        return net.minecraft.block.BlockPlanks.EnumType.OAK;
    }

    @Override
    public java.util.List<net.minecraft.item.ItemStack> onSheared(net.minecraft.item.ItemStack item, net.minecraft.world.IBlockAccess world, net.minecraft.util.math.BlockPos pos, int fortune) {
        return java.util.Collections.emptyList();
    }

    public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
        par3List.add(new ItemStack(Item.getItemFromBlock((Block)this), 1, 0));
    }

    public void dropBlockAsItemWithChance(World par1World, int par2, int par3, int par4, int par5, float par6, int par7) {
        if (!par1World.isRemote && par1World.rand.nextInt(25) == 1) {
            net.minecraft.util.math.BlockPos pos = new net.minecraft.util.math.BlockPos(par2, par3, par4);
            if (this == ChaosPersists.MyCherryLeaves) {
                Block.spawnAsEntity(par1World, pos, new ItemStack(ChaosPersists.MyCherry));
            }
            if (this == ChaosPersists.MyPeachLeaves) {
                Block.spawnAsEntity(par1World, pos, new ItemStack(ChaosPersists.MyPeach));
            }
        }
    }

    public int quantityDropped(Random par1Random) {
        if (this == ChaosPersists.MyCherryLeaves) {
            return par1Random.nextInt(4);
        }
        if (this == ChaosPersists.MyPeachLeaves) {
            return par1Random.nextInt(1);
        }
        return 0;
    }

    public void updateTick(World par1World, BlockPos pos, IBlockState state, Random par5Random) {
        int par2 = pos.getX(), par3 = pos.getY(), par4 = pos.getZ();
        int var7 = 2;
        int totaldist = 0;
        if (!par1World.isRemote && par1World.isAreaLoaded(pos.add(-var7, -var7, -var7), pos.add(var7, var7, var7))) {
            for (int var12 = - var7; var12 <= var7; ++var12) {
                for (int var13 = - var7; var13 <= 0; ++var13) {
                    for (int var14 = - var7; var14 <= var7; ++var14) {
                        Block bid;
                        net.minecraft.util.math.BlockPos off = new net.minecraft.util.math.BlockPos(par2 + var12, par3 + var13, par4 + var14);
                        totaldist = Math.abs(var12) + Math.abs(var13) + Math.abs(var14);
                        if (totaldist > 3 || (bid = par1World.getBlockState(off).getBlock()) == null || !bid.canSustainLeaves(par1World.getBlockState(off), (IBlockAccess)par1World, off)) continue;
                        long t = par1World.getWorldTime();
                        if (this == ChaosPersists.MyScaryLeaves && (t %= 24000L) < 12000L) {
                            ChaosPersists.setBlockFast((World)par1World, (int)par2, (int)par3, (int)par4, (Block)ChaosPersists.MyAppleLeaves, (int)0, (int)3);
                        }
                        if ((bid = par1World.getBlockState(new net.minecraft.util.math.BlockPos(par2, par3 - 1, par4)).getBlock()) == Blocks.AIR && par1World.rand.nextInt(20) == 3) {
                            this.dropBlockAsItemWithChance(par1World, par2, par3 - 1, par4, 0, 0.0f, 0);
                        }
                        return;
                    }
                }
            }
            this.removeLeaves(par1World, par2, par3, par4);
        }
    }

    public void randomDisplayTick(World par1World, int par2, int par3, int par4, Random par5Random) {
    }

    private void removeLeaves(World par1World, int par2, int par3, int par4) {
        net.minecraft.util.math.BlockPos pos = new net.minecraft.util.math.BlockPos(par2, par3, par4);
        this.dropBlockAsItem(par1World, pos, par1World.getBlockState(pos), 0);
        par1World.setBlockState(pos, Blocks.AIR.getDefaultState(), 2);
    }

    public boolean isOpaqueCube() {
        if (ChaosPersists.FastGraphicsLeaves != 0) {
            return true;
        }
        return false;
    }

    @SideOnly(value=Side.CLIENT)
    public boolean shouldSideBeRendered(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5) {
        Block i1 = par1IBlockAccess.getBlockState(new net.minecraft.util.math.BlockPos(par2, par3, par4)).getBlock();
        return ChaosPersists.FastGraphicsLeaves == 0 || i1 != this;
    }

    public String[] func_150125_e() {
        return null;
    }
}

