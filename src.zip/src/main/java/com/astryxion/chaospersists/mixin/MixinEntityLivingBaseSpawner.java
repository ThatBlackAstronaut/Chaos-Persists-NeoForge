package com.astryxion.chaospersists.mixin;

import com.astryxion.chaospersists.util.SpawnerFixHelper;
import net.minecraft.entity.EntityLiving;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Universal spawner fix: Chaos Persists entities from package
 * com.astryxion.chaospersists.entity always pass spawn validation when
 * spawned from a mob spawner (ticksExisted == 0). Does not affect vanilla mobs.
 *
 * Both getCanSpawnHere() and isNotColliding() are defined in EntityLiving in 1.12.2.
 * Runtime check is in SpawnerFixHelper (outside mixin package) so this class is never loaded.
 */
public final class MixinEntityLivingBaseSpawner {

    @Mixin(EntityLiving.class)
    public static final class GetCanSpawnHere {
        @Inject(method = "getCanSpawnHere", at = @At("HEAD"), cancellable = true, require = 1)
        private void onGetCanSpawnHere(CallbackInfoReturnable<Boolean> cir) {
            EntityLiving self = (EntityLiving) (Object) this;
            if (SpawnerFixHelper.isChaosEntityFirstTick(self)) {
                cir.setReturnValue(true);
                cir.cancel();
            }
        }
    }

    @Mixin(EntityLiving.class)
    public static final class IsNotColliding {
        @Inject(method = "isNotColliding", at = @At("HEAD"), cancellable = true, require = 1)
        private void onIsNotColliding(CallbackInfoReturnable<Boolean> cir) {
            EntityLiving self = (EntityLiving) (Object) this;
            if (SpawnerFixHelper.isChaosEntityFirstTick(self)) {
                cir.setReturnValue(true);
                cir.cancel();
            }
        }
    }
}
