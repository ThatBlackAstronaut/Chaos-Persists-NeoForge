/*
 * Decompiled with CFR 0_125.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 *  com.astryxion.chaospersists.ItemPizza
 *  net.minecraft.block.Block
 *  net.minecraft.block.Block$SoundType
 *  net.minecraft.block.BlockDeadBush
 *  net.minecraft.block.BlockTallGrass
 *  net.minecraft.client.renderer.texture.IIconRegister
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.IIcon
 *  net.minecraft.world.World
 */
package com.astryxion.chaospersists.item;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDeadBush;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ItemPizza
extends Item {
    private Block spawnID;

    public ItemPizza(Block par2Block) {
        this.spawnID = par2Block;
    }

    public boolean onItemUse(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, World par3World, int par4, int par5, int par6, int par7, float par8, float par9, float par10) {
        BlockPos pos = new BlockPos(par4, par5, par6);
        Block i1 = par3World.getBlockState(pos).getBlock();
        if (i1 == Blocks.SNOW_LAYER && (i1.getMetaFromState(par3World.getBlockState(pos)) & 7) < 1) {
            par7 = 1;
        } else if (i1 != Blocks.VINE && i1 != Blocks.TALLGRASS && i1 != Blocks.DEADBUSH) {
            if (par7 == 0) {
                --par5;
            }
            if (par7 == 1) {
                ++par5;
            }
            if (par7 == 2) {
                --par6;
            }
            if (par7 == 3) {
                ++par6;
            }
            if (par7 == 4) {
                --par4;
            }
            if (par7 == 5) {
                ++par4;
            }
        }
        EnumFacing facing = EnumFacing.byIndex(par7);
        if (!par2EntityPlayer.canPlayerEdit(pos, facing, par1ItemStack)) {
            return false;
        }
        if (par1ItemStack.getCount() == 0) {
            return false;
        }
        IBlockState state = this.spawnID.getStateForPlacement(par3World, pos, facing, (float)par8, (float)par9, (float)par10, 0, (EntityLivingBase)par2EntityPlayer);
        if (state != null && par3World.mayPlace(this.spawnID, pos, false, facing, (Entity)null) && par3World.setBlockState(pos, state, 3)) {
            if (par3World.getBlockState(pos).getBlock() == this.spawnID) {
                this.spawnID.onBlockPlacedBy(par3World, pos, state, (EntityLivingBase)par2EntityPlayer, par1ItemStack);
            }
            par3World.playSound(null, pos, this.spawnID.getSoundType(state, par3World, pos, par2EntityPlayer).getPlaceSound(), SoundCategory.BLOCKS, (this.spawnID.getSoundType(state, par3World, pos, par2EntityPlayer).getVolume() + 1.0f) / 2.0f, this.spawnID.getSoundType(state, par3World, pos, par2EntityPlayer).getPitch() * 0.8f);
            par1ItemStack.shrink(1);
        }
        return true;
    }}

