/*
 * Decompiled with CFR 0_125.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 *  com.astryxion.chaospersists.ItemRandomDungeon
 *  com.astryxion.chaospersists.ChaosPersists
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockGrass
 *  net.minecraft.client.renderer.texture.IIconRegister
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.PlayerCapabilities
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.IIcon
 *  net.minecraft.world.World
 */
package com.astryxion.chaospersists.item;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import com.astryxion.chaospersists.core.ChaosPersists;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockGrass;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ItemRandomDungeon
extends Item {
    Random rand = ChaosPersists.ChaosRand;

    public ItemRandomDungeon(int i) {
        this.maxStackSize = 1;
        this.setCreativeTab(CreativeTabs.REDSTONE);
    }

    public void onCreated(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
        par1ItemStack.addEnchantment(Enchantments.SILK_TOUCH, 2);
    }

    public void onUsingTick(ItemStack stack, EntityPlayer player, int count) {
        int lvl = EnchantmentHelper.getEnchantmentLevel(Enchantments.SILK_TOUCH, stack);
        if (lvl <= 0) {
            stack.addEnchantment(Enchantments.SILK_TOUCH, 2);
        }
    }

    public void onUpdate(ItemStack stack, World par2World, Entity par3Entity, int par4, boolean par5) {
        this.onUsingTick(stack, (EntityPlayer)null, 0);
    }

    @Override
    public EnumActionResult onItemUse(EntityPlayer par2EntityPlayer, World world, BlockPos pos, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
        ItemStack par1ItemStack = par2EntityPlayer.getHeldItem(hand);
        int clickedX = pos.getX();
        int clickedY = pos.getY();
        int clickedZ = pos.getZ();
        Block var1 = world.getBlockState(new net.minecraft.util.math.BlockPos(clickedX, clickedY, clickedZ)).getBlock();
        if (var1 != Blocks.STONE && var1 != Blocks.COBBLESTONE && var1 != Blocks.GRASS && var1 != Blocks.DIRT) {
            return EnumActionResult.FAIL;
        }
        if (clickedY < 40) {
            return EnumActionResult.FAIL;
        }
        if (!world.isRemote) {
            world.setBlockState(new net.minecraft.util.math.BlockPos(clickedX, clickedY + 1, clickedZ), ChaosPersists.MyDungeonSpawnerBlock.getDefaultState(), 2);
        }
        if (!par2EntityPlayer.capabilities.isCreativeMode) {
            par1ItemStack.shrink(1);
        }
        return EnumActionResult.SUCCESS;
    }}

