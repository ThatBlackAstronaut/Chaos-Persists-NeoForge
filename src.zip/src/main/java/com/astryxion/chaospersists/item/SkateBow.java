package com.astryxion.chaospersists.item;

import com.astryxion.chaospersists.core.ChaosPersists;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Enchantments;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

public class SkateBow extends Item {

    public SkateBow(int par1) {
        this.maxStackSize = 1;
        this.setMaxDamage(300);
        this.setCreativeTab(CreativeTabs.COMBAT);
    }

    @Override
    public int getMaxItemUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public EnumAction getItemUseAction(ItemStack stack) {
        return EnumAction.BOW;
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        player.setActiveHand(hand);
        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }

    @Override
    public void onPlayerStoppedUsing(ItemStack stack, World world, EntityLivingBase entity, int timeLeft) {

        if (!(entity instanceof EntityPlayer)) return;

        EntityPlayer player = (EntityPlayer) entity;

        boolean hasInfinity =
                player.capabilities.isCreativeMode ||
                EnchantmentHelper.getEnchantmentLevel(Enchantments.INFINITY, stack) > 0;

        if (!hasInfinity && countArrows(player) <= 0) {
            return;
        }

        int charge = this.getMaxItemUseDuration(stack) - timeLeft;
        float velocity = charge / 20.0F;
        velocity = (velocity * velocity + velocity * 2.0F) / 3.0F;

        if (velocity < 0.1F) return;
        if (velocity > 1.75F) velocity = 1.75F;

        IrukandjiArrow arrow = new IrukandjiArrow(world, player, velocity);

        if (world.rand.nextInt(20) == 1) {
            arrow.setIsCritical(true);
        }

        int punchLevel = EnchantmentHelper.getEnchantmentLevel(Enchantments.PUNCH, stack);
        if (punchLevel > 0) {
            arrow.setKnockbackStrength(punchLevel);
        }

        if (EnchantmentHelper.getEnchantmentLevel(Enchantments.FLAME, stack) > 0) {
            arrow.setFire(100);
        }

        stack.damageItem(1, player);

        world.playSound(
                null,
                player.posX,
                player.posY,
                player.posZ,
                SoundEvents.ENTITY_ARROW_SHOOT,
                player.getSoundCategory(),
                1.0F,
                1.0F / (itemRand.nextFloat() * 0.4F + 1.2F) + 0.5F
        );

        if (!hasInfinity) {
            consumeOneArrow(player);
        }

        if (!world.isRemote) {
            world.spawnEntity(arrow);
        }
    }

    @Override
    public int getItemEnchantability() {
        return 50;
    }

    private int countArrows(EntityPlayer player) {
        int count = 0;
        for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
            ItemStack s = player.inventory.getStackInSlot(i);
            if (!s.isEmpty() && s.getItem() == ChaosPersists.MyIrukandjiArrow) {
                count += s.getCount();
            }
        }
        return count;
    }

    private void consumeOneArrow(EntityPlayer player) {
        for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
            ItemStack s = player.inventory.getStackInSlot(i);
            if (!s.isEmpty() && s.getItem() == ChaosPersists.MyIrukandjiArrow) {
                s.shrink(1);
                break;
            }
        }
    }
}
