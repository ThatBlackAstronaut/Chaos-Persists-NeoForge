/*
 * Decompiled with CFR 0_125.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 *  com.astryxion.chaospersists.ItemZooKeeper
 *  net.minecraft.client.renderer.texture.IIconRegister
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLiving
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.InventoryPlayer
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.IIcon
 *  net.minecraft.world.World
 */
package com.astryxion.chaospersists.item;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import java.util.Random;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemZooKeeper
extends Item {
    public ItemZooKeeper(int i) {
        this.setCreativeTab(CreativeTabs.DECORATIONS);
        this.setMaxDamage(1);
    }

    public boolean onLeftClickEntity(ItemStack stack, EntityPlayer player, Entity entity) {
        for (int var3 = 0; var3 < 8; ++var3) {
            float f1 = player.world.rand.nextFloat() * 3.0f - player.world.rand.nextFloat() * 3.0f;
            float f2 = 0.25f + player.world.rand.nextFloat() * 2.0f;
            float f3 = player.world.rand.nextFloat() * 3.0f - player.world.rand.nextFloat() * 3.0f;
            player.world.spawnParticle(net.minecraft.util.EnumParticleTypes.SMOKE_NORMAL, (double)((float)entity.posX + f1), (double)((float)entity.posY + f2), (double)((float)entity.posZ + f3), 0.0, 0.0, 0.0);
            f1 = player.world.rand.nextFloat() * 3.0f - player.world.rand.nextFloat() * 3.0f;
            f2 = 0.25f + player.world.rand.nextFloat() * 2.0f;
            f3 = player.world.rand.nextFloat() * 3.0f - player.world.rand.nextFloat() * 3.0f;
            player.world.spawnParticle(net.minecraft.util.EnumParticleTypes.EXPLOSION_NORMAL, (double)((float)entity.posX + f1), (double)((float)entity.posY + f2), (double)((float)entity.posZ + f3), 0.0, 0.0, 0.0);
            f1 = player.world.rand.nextFloat() * 3.0f - player.world.rand.nextFloat() * 3.0f;
            f2 = 0.25f + player.world.rand.nextFloat() * 2.0f;
            f3 = player.world.rand.nextFloat() * 3.0f - player.world.rand.nextFloat() * 3.0f;
            player.world.spawnParticle(net.minecraft.util.EnumParticleTypes.REDSTONE, (double)((float)entity.posX + f1), (double)((float)entity.posY + f2), (double)((float)entity.posZ + f3), 0.0, 0.0, 0.0);
        }
        player.world.playSound(player.posX, player.posY, player.posZ, net.minecraft.util.SoundEvent.REGISTRY.getObject(new net.minecraft.util.ResourceLocation("random.explode")), net.minecraft.util.SoundCategory.PLAYERS, 0.5f, 1.5f, false);
        if (entity == null || !(entity instanceof EntityLiving)) {
            return false;
        }
        EntityLiving e = (EntityLiving)entity;
        e.enablePersistence();
        stack.damageItem(2, (EntityLivingBase)player);
        if (stack.getCount() <= 0) {
            player.inventory.setInventorySlotContents(player.inventory.currentItem, net.minecraft.item.ItemStack.EMPTY);
        }
        return true;
    }}

