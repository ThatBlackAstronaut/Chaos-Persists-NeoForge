/*
 * Decompiled with CFR 0_125.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 *  com.astryxion.chaospersists.EntityThrownRock
 *  com.astryxion.chaospersists.ItemRock
 *  com.astryxion.chaospersists.ChaosPersists
 *  com.astryxion.chaospersists.RockBase
 *  net.minecraft.client.renderer.texture.IIconRegister
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityList
 *  net.minecraft.entity.EntityLiving
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.PlayerCapabilities
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.IIcon
 *  net.minecraft.world.World
 */
package com.astryxion.chaospersists.item;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import com.astryxion.chaospersists.entity.EntityThrownRock;
import com.astryxion.chaospersists.core.ChaosPersists;
import com.astryxion.chaospersists.entity.RockBase;
import java.util.Random;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemRock
extends Item {
    public ItemRock(int i) {
        this.maxStackSize = 64;
        this.setCreativeTab(CreativeTabs.COMBAT);
    }

    public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
        if (!par3EntityPlayer.capabilities.isCreativeMode) {
            par1ItemStack.shrink(1);
        }
        par2World.playSound(par3EntityPlayer.posX, par3EntityPlayer.posY, par3EntityPlayer.posZ, net.minecraft.util.SoundEvent.REGISTRY.getObject(new net.minecraft.util.ResourceLocation("random.bow")), net.minecraft.util.SoundCategory.PLAYERS, 0.5f, 0.4f / (itemRand.nextFloat() * 0.4f + 0.8f), false);
        if (!par2World.isRemote) {
            if (this == ChaosPersists.MySmallRock) {
                par2World.spawnEntity((Entity)new EntityThrownRock(par2World, (EntityLivingBase)par3EntityPlayer, 1));
            }
            if (this == ChaosPersists.MyRock) {
                par2World.spawnEntity((Entity)new EntityThrownRock(par2World, (EntityLivingBase)par3EntityPlayer, 2));
            }
            if (this == ChaosPersists.MyRedRock) {
                par2World.spawnEntity((Entity)new EntityThrownRock(par2World, (EntityLivingBase)par3EntityPlayer, 3));
            }
            if (this == ChaosPersists.MyGreenRock) {
                par2World.spawnEntity((Entity)new EntityThrownRock(par2World, (EntityLivingBase)par3EntityPlayer, 4));
            }
            if (this == ChaosPersists.MyBlueRock) {
                par2World.spawnEntity((Entity)new EntityThrownRock(par2World, (EntityLivingBase)par3EntityPlayer, 5));
            }
            if (this == ChaosPersists.MyPurpleRock) {
                par2World.spawnEntity((Entity)new EntityThrownRock(par2World, (EntityLivingBase)par3EntityPlayer, 6));
            }
            if (this == ChaosPersists.MySpikeyRock) {
                par2World.spawnEntity((Entity)new EntityThrownRock(par2World, (EntityLivingBase)par3EntityPlayer, 7));
            }
            if (this == ChaosPersists.MyTNTRock) {
                par2World.spawnEntity((Entity)new EntityThrownRock(par2World, (EntityLivingBase)par3EntityPlayer, 8));
            }
            if (this == ChaosPersists.MyCrystalRedRock) {
                par2World.spawnEntity((Entity)new EntityThrownRock(par2World, (EntityLivingBase)par3EntityPlayer, 9));
            }
            if (this == ChaosPersists.MyCrystalGreenRock) {
                par2World.spawnEntity((Entity)new EntityThrownRock(par2World, (EntityLivingBase)par3EntityPlayer, 10));
            }
            if (this == ChaosPersists.MyCrystalBlueRock) {
                par2World.spawnEntity((Entity)new EntityThrownRock(par2World, (EntityLivingBase)par3EntityPlayer, 11));
            }
            if (this == ChaosPersists.MyCrystalTNTRock) {
                par2World.spawnEntity((Entity)new EntityThrownRock(par2World, (EntityLivingBase)par3EntityPlayer, 12));
            }
        }
        return par1ItemStack;
    }

    public boolean onItemUse(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, World world, int x, int y, int z, int par7, float par8, float par9, float par10) {
        if (!world.isRemote) {
            Entity e;
            if (x < 0) {
                ++x;
            }
            if (z < 0) {
                ++z;
            }
            if ((e = this.spawnCreature(world, "Rock", (double)x, (double)y + 1.01, (double)z)) != null) {
                RockBase r = (RockBase)e;
                if (this == ChaosPersists.MySmallRock) {
                    r.placeRock(1);
                }
                if (this == ChaosPersists.MyRock) {
                    r.placeRock(2);
                }
                if (this == ChaosPersists.MyRedRock) {
                    r.placeRock(3);
                }
                if (this == ChaosPersists.MyGreenRock) {
                    r.placeRock(4);
                }
                if (this == ChaosPersists.MyBlueRock) {
                    r.placeRock(5);
                }
                if (this == ChaosPersists.MyPurpleRock) {
                    r.placeRock(6);
                }
                if (this == ChaosPersists.MySpikeyRock) {
                    r.placeRock(7);
                }
                if (this == ChaosPersists.MyTNTRock) {
                    r.placeRock(8);
                }
                if (this == ChaosPersists.MyCrystalRedRock) {
                    r.placeRock(9);
                }
                if (this == ChaosPersists.MyCrystalGreenRock) {
                    r.placeRock(10);
                }
                if (this == ChaosPersists.MyCrystalBlueRock) {
                    r.placeRock(11);
                }
                if (this == ChaosPersists.MyCrystalTNTRock) {
                    r.placeRock(12);
                }
            }
        }
        if (!par2EntityPlayer.capabilities.isCreativeMode) {
            par1ItemStack.shrink(1);
        }
        return true;
    }

    private Entity spawnCreature(World par0World, String par1, double par2, double par4, double par6) {
        Entity var8 = null;
        var8 = EntityList.createEntityByIDFromName(new net.minecraft.util.ResourceLocation("chaospersists", (String)par1), par0World);
        if (var8 != null) {
            if (par2 > 0.0) {
                par2 += 0.5;
            }
            if (par2 < 0.0) {
                par2 -= 0.5;
            }
            if (par6 > 0.0) {
                par6 += 0.5;
            }
            if (par6 < 0.0) {
                par6 -= 0.5;
            }
            var8.setLocationAndAngles(par2, par4 + 0.01, par6, par0World.rand.nextFloat() * 360.0f, 0.0f);
            par0World.spawnEntity(var8);
            ((EntityLiving)var8).playLivingSound();
        }
        return var8;
    }}

