/*
 * Decompiled with CFR 0_125.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 *  com.astryxion.chaospersists.ItemDuctTape
 *  net.minecraft.block.Block
 *  net.minecraft.block.Block$SoundType
 *  net.minecraft.block.BlockDeadBush
 *  net.minecraft.block.BlockTallGrass
 *  net.minecraft.client.renderer.texture.IIconRegister
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.IIcon
 *  net.minecraft.world.World
 */
package com.astryxion.chaospersists.item;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDeadBush;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.state.IBlockState;
import net.minecraft.world.World;

public class ItemDuctTape
extends Item {
    private Block field_150935_a;

    public ItemDuctTape(Block par2Block) {
        this.field_150935_a = par2Block;
    }

    public boolean onItemUse(ItemStack p_77648_1_, EntityPlayer p_77648_2_, World p_77648_3_, int p_77648_4_, int p_77648_5_, int p_77648_6_, int p_77648_7_, float p_77648_8_, float p_77648_9_, float p_77648_10_) {
        BlockPos pos = new BlockPos(p_77648_4_, p_77648_5_, p_77648_6_);
        Block block = p_77648_3_.getBlockState(pos).getBlock();
        if (block == Blocks.SNOW_LAYER && (block.getMetaFromState(p_77648_3_.getBlockState(pos)) & 7) < 1) {
            p_77648_7_ = 1;
        } else if (block != Blocks.VINE && block != Blocks.TALLGRASS && block != Blocks.DEADBUSH) {
            if (p_77648_7_ == 0) {
                --p_77648_5_;
            }
            if (p_77648_7_ == 1) {
                ++p_77648_5_;
            }
            if (p_77648_7_ == 2) {
                --p_77648_6_;
            }
            if (p_77648_7_ == 3) {
                ++p_77648_6_;
            }
            if (p_77648_7_ == 4) {
                --p_77648_4_;
            }
            if (p_77648_7_ == 5) {
                ++p_77648_4_;
            }
        }
        EnumFacing facing = EnumFacing.byIndex(p_77648_7_);
        if (!p_77648_2_.canPlayerEdit(pos, facing, p_77648_1_)) {
            return false;
        }
        if (p_77648_1_.getCount() == 0) {
            return false;
        }
        IBlockState state = this.field_150935_a.getStateForPlacement(p_77648_3_, pos, facing, (float)p_77648_8_, (float)p_77648_9_, (float)p_77648_10_, 0, (EntityLivingBase)p_77648_2_);
        if (state != null && p_77648_3_.mayPlace(this.field_150935_a, pos, false, facing, (Entity)null) && p_77648_3_.setBlockState(pos, state, 3)) {
            if (p_77648_3_.getBlockState(pos).getBlock() == this.field_150935_a) {
                this.field_150935_a.onBlockPlacedBy(p_77648_3_, pos, state, (EntityLivingBase)p_77648_2_, p_77648_1_);
            }
            p_77648_3_.playSound(null, pos, this.field_150935_a.getSoundType(state, p_77648_3_, pos, p_77648_2_).getPlaceSound(), SoundCategory.BLOCKS, (this.field_150935_a.getSoundType(state, p_77648_3_, pos, p_77648_2_).getVolume() + 1.0f) / 2.0f, this.field_150935_a.getSoundType(state, p_77648_3_, pos, p_77648_2_).getPitch() * 0.8f);
            p_77648_1_.shrink(1);
        }
        return true;
    }}

